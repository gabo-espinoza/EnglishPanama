﻿# English Panamá - Backend (Daniel Gómez)

Implementación parcial correspondiente a Auth + Usuarios + Panel Docente + Modo Demo.

